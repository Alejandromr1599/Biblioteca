drop database if exists Biblioteca;
CREATE DATABASE Biblioteca;
use Biblioteca;
CREATE TABLE usuarios(

id int auto_increment primary key,
nombre varchar (30),
apellido varchar (30),
DNI varchar (10),
Domicilio varchar (200),
telefono varchar (9)
);
select * from usuarios;

CREATE TABLE libros(
id int auto_increment primary key,
nombre varchar (100),
autor varchar (100),
disponibilidad varchar (100)
);
select * from libros;

CREATE TABLE prestamos(
dni varchar (9)  primary key,
id_libro int  
);

