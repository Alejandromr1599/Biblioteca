/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gestionbiblioteca;

/**
 *
 * @author Admin
 */
public class GestionBiblioteca {

    public static void main(String[] args) {
        Biblioteca nuevo = new Biblioteca();
        nuevo.setVisible(true);
    }
}
